
from itertools import count


a={'h','a','r','i','i','i'}

for i in a:
    print(i)