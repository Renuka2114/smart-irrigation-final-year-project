from msilib.schema import Binary


Binary(27)